# Wuthering Waves Resonance Feed

A self-updating leak tracker. GitHub Actions runs on a schedule, asks Claude
to web-search for new Wuthering Waves leaks, and commits the results to
`docs/leaks.json`. The static page in `docs/index.html` (served via GitHub
Pages) reads that file — so the feed updates itself with no server of your
own and no exposed API key.

## Setup

1. Create a new GitHub repo and push these files (`.github/`, `scripts/`, `docs/`).
2. Get an API key from console.anthropic.com.
3. In the repo: **Settings → Secrets and variables → Actions → New repository secret**
   - Name: `ANTHROPIC_API_KEY`
   - Value: your key
4. **Settings → Pages** → Source: `Deploy from a branch` → Branch: `main` / `docs`.
5. **Actions tab** → run "Scan Wuthering Waves leaks" once manually (workflow_dispatch)
   to populate `docs/leaks.json` for the first time.
6. Visit your Pages URL (something like `https://<you>.github.io/<repo>/`).

The workflow re-runs every 6 hours by default — change the cron line in
`.github/workflows/scan-leaks.yml` to adjust frequency. Each run only costs
one Claude API call with web search, so keep an eye on usage/billing in the
Anthropic console.

You can still add your own leaks by hand in the app itself — those are
stored in your browser and layer on top of the auto-scanned feed.
